<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ministere</title>
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <link rel="stylesheet" href="../dossier/css/pages.css">
    <link rel="stylesheet" href="../dossier/css/style.css">
</head>
<body>
   <?php  include "../entete.php";?>

<div class="table">
 <table class="table table-success table-striped table caption-top">
  <thead>
    <tr>
    <th scope="col">Code Ministere</th>
      <th scope="col">Nom Ministere</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
      
        include '../dbconnect.php';

        if (isset($_POST['rechercher'])) {

            $codeM = $_POST['codeM'];
            $elements = $connexion->query("Select * from ministere WHERE codeM = '". $codeM . "'");
           while ($row = $elements->fetch()){?>
         
           <tr>
           <td><?php echo $row["codeM"] ;?></td>
             <td><?php echo $row["nomM"] ;?></td>
           </tr>

      <?php } }?>
    </tr>
  </tbody>
</table>
</div>
<script src='../js/bootstrap.min.js'></script>
</body>
</html>