<?php
include '../dbconnect.php';
$q = $connexion->query("SELECT * FROM services WHERE codeS='" . $_GET["codeS"] . "'");

while ($row = $q->fetch(PDO::FETCH_ASSOC)) {

    $codeS=$row["codeS"]; 
    $nomS=$row["nomS"]; 
    $descript=$row["descript"];
}

if (isset($_POST['modifier'])) {

   
    $codeS=$_POST["codeS"]; 
    $nomS=$_POST["nomS"]; 
    $descript=$_POST["descript"];
    
       
    $r = "UPDATE services SET codeS='$codeS',nomS='$nomS',descript='$descript'  WHERE codeS = '" . $_GET["codeS"] . "'";
    $connexion->exec($r);

    $location = $_SERVER['HTTP_REFERER'];
    if ($r) {
        header('Location: service.php');
    } 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service</title>
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <link rel="stylesheet" href="../dossier/css/pages.css">
    <link rel="stylesheet" href="../dossier/css/style.css">
</head>
<body>
   <?php include "../entete.php";?>
   <div class="corps">
<form class="row gx-3 gy-2 align-items-center" action="" method="post">
  <div class="col-sm-3">
    <label for="idagent">Code_Service</label>
    <input type="number" name="codeS" class="form-control" id="specificSizeInputName" value="<?php echo $codeS; ?>">
  </div>
  <div class="col-sm-3">
    <label for="nom">Nom_Service</label>
    <input type="text" name="nomS" class="form-control" id="specificSizeInputName" value="<?php echo $nomS; ?>">
  </div>
  <div class="col-sm-3">
    <label for="prenom">Description</label>
    <input type="text"  name="descript" class="form-control" id="specificSizeInputName" value="<?php echo $descript; ?>">
  </div>
  <br>
  <div class="col-md-6">
   <button type="submit" name="modifier" class="btn btn-primary">Modifier</button>
  </div>
</form>
</div>
<script src='../js/bootstrap.min.js'></script>
</body>
</html>