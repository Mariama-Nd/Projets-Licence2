<?php
include '../dbconnect.php';
$q = $connexion->query("SELECT * FROM rattacher WHERE idR='" . $_GET["idR"] . "'");

while ($row = $q->fetch(PDO::FETCH_ASSOC)) {

    $idR=$row["idR"];
    $codeS=$row["codeS"]; 
    $codeM=$row["codeM"]; 
    $dated=$row["dated"];
    $datef=$row["datef"];
    $budget=$row["budget"];
}

if (isset($_POST['modifier'])) {

    $idR=$_POST["idR"];
    $codeS=$_POST["codeS"]; 
    $codeM=$_POST["codeM"]; 
    $dated=$_POST["dated"];
    $datef=$_POST["datef"];
    $budget=$_POST["budget"];
       
    $r = "UPDATE rattacher SET idR='$idR',codeS='$codeS',codeM='$codeM',dated='$dated',datef='$datef',budget='$budget'  WHERE idR = '" . $_GET["idR"] . "'";
    $connexion->exec($r);

    $location = $_SERVER['HTTP_REFERER'];
    if ($r) {
        header('Location: rattacher.php');
    } 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>rattacherer</title>
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <link rel="stylesheet" href="../dossier/css/pages.css">
    <link rel="stylesheet" href="../dossier/css/style.css">
</head>
<body>
   <?php  include "../entete.php";?>
   <div class="corps">
<fieldset>
<form class="row gx-3 gy-2 align-items-center" action="" method="post">
  <div class="col-sm-3">
    <label for="idagent">Id_Rattachement</label>
    <input type="number" name="idR" class="form-control" id="specificSizeInputName" value="<?php echo $idR; ?>">
  </div>
  <div class="col-sm-3">
    <label for="codeS">Code_Service</label>
    <select class="form-select" id="specificSizeSelect" name="codeS">
    <?php
        include '../dbconnect.php';
        $stmt = $connexion->query("SELECT * FROM services");
        while ($row = $stmt->fetch()) { ?>
          <option value="<?php echo $row["codeS"]; ?>">
          <?php echo $row['nomS']; ?></option>
        <?php
          }
        ?>
    </select>
  </div>
  <div class="col-sm-3">
    <label for="codeM">Code_Ministere</label>
    <select class="form-select" id="specificSizeSelect" name="codeM">
    <?php
        include '../dbconnect.php';
        $stmt = $connexion->query("SELECT * FROM ministere");
        while ($row = $stmt->fetch()) { ?>
          <option value="<?php echo $row["codeM"]; ?>">
          <?php echo $row['codeM']; ?></option>
        <?php
          }
        ?>
    </select>
  </div>
  <div class="col-sm-3">
    <label for="dated">Date_Debut</label>
    <input type="date"  name="dated" class="form-control" id="specificSizeInputName" value="<?php echo $dated; ?>">
  </div>
  <div class="col-sm-3">
    <label for="datef">Date_Fin</label>
    <input type="date"  name="datef" class="form-control" id="specificSizeInputName" value="<?php echo $datef; ?>">
  </div>
  <div class="col-sm-3">
    <label for="budget">Budget</label>
    <input type="number" name="budget" class="form-control" id="specificSizeInputName" value="<?php echo $budget; ?>">
  </div>
  <br>
  <div class="col-md-6">
   <button type="submit" name="modifier" class="btn btn-primary">Modifier</button>
  </div>
</form>
</div>
<script src='../js/bootstrap.min.js'></script>
</body>
</html>

