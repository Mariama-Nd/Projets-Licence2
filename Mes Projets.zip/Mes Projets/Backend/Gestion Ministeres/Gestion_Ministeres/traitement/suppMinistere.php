<?php

include '../dbconnect.php';

$r = "DELETE FROM ministere WHERE codeM = '" . $_GET["codeM"] . "'";
$connexion->query($r);
echo $r;
if ($r) {
    $location = $_SERVER['HTTP_REFERER'];
    header('Location: ministere.php?delete=1');
}
?>