<?php
include '../dbconnect.php';
$q = $connexion->query("SELECT * FROM affecter WHERE numero='" . $_GET["numero"] . "'");

while ($row = $q->fetch(PDO::FETCH_ASSOC)) {

    $numero=$row["numero"];
    $codeS=$row["codeS"]; 
    $idA=$row["idA"]; 
    $dateAf=$row["dateAf"];
    
}

if (isset($_POST['modifier'])) {

    $numero=$_POST["numero"];
    $codeS=$_POST["codeS"]; 
    $idA=$_POST["idA"]; 
    $dateAf=$_POST["dateAf"];
       
    $r = "UPDATE affecter SET numero='$numero',codeS='$codeS',idA='$idA',dateAf='$dateAf'  WHERE numero = '" . $_GET["numero"] . "'";
    $connexion->exec($r);

    $location = $_SERVER['HTTP_REFERER'];
    if ($r) {
        header('Location: affecter.php');
    } 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Affecter</title>
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <link rel="stylesheet" href="../dossier/css/pages.css">
    <link rel="stylesheet" href="../dossier/css/style.css">
</head>
<body>
   <?php  include "../entete.php";?>
   <div class="corps">
<fieldset>
<form class="row gx-3 gy-2 align-items-center" action="" method="post">
  <div class="col-sm-3">
    <label for="numero">Numero_Affectation</label>
    <input type="number" name="numero" class="form-control" id="specificSizeInputName" value="<?php echo $numero; ?>">
  </div>
  <div class="col-sm-3">
    <label for="codeS">Code_Service</label>
    <select class="form-select" id="specificSizeSelect" name="codeS">
    <?php
        include '../dbconnect.php';
        $stmt = $connexion->query("SELECT * FROM services");
        while ($row = $stmt->fetch()) { ?>
          <option value="<?php echo $row["codeS"]; ?>">
          <?php echo $row['nomS']; ?></option>
        <?php
          }
        ?>
    </select>
  </div>
  <div class="col-sm-3">
    <label for="idA">Id_Agent</label>
    <select class="form-select" id="specificSizeSelect" name="idA">
    <?php
        include '../dbconnect.php';
        $stmt = $connexion->query("SELECT * FROM agent");
        while ($row = $stmt->fetch()) { ?>
          <option value="<?php echo $row["idA"]; ?>">
          <?php echo $row['nomA']; ?></option>
        <?php
          }
        ?>
    </select>
  </div>
  <div class="col-sm-3">
    <label for="dateAf">Date_Affectation</label>
    <input type="date"  name="dateAf" class="form-control" id="specificSizeInputName" value="<?php echo $dateAf; ?>">
  </div>
  <br>
  <div class="col-md-6">
   <button type="submit" name="modifier" class="btn btn-primary">Modifier</button>
  </div>
</form>
</div>
<script src='../js/bootstrap.min.js'></script>
</body>
</html>