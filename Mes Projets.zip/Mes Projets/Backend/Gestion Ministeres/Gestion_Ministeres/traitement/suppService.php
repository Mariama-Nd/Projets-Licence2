<?php

include '../dbconnect.php';

$r = "DELETE FROM services WHERE codeS = '" . $_GET["codeS"] . "'";
$connexion->query($r);
echo $r;
if ($r) {
    $location = $_SERVER['HTTP_REFERER'];
    header('Location: service.php?delete=1');
}
?>