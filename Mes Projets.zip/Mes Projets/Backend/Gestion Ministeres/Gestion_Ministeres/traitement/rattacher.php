<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>rattacherer</title>
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <link rel="stylesheet" href="../dossier/css/pages.css">
    <link rel="stylesheet" href="../dossier/css/style.css">
</head>
<body>
   <?php  include "../entete.php";?>
   <div class="corps">
<fieldset>
<form class="row gx-3 gy-2 align-items-center" action="foncRattacher.php" method="post">
  <div class="col-sm-3">
    <label for="idagent">Id_Rattachement</label>
    <input type="number" name="idR" class="form-control" id="specificSizeInputName" >
  </div>
  <div class="col-sm-3">
    <label for="codeS">Code_Service</label>
    <select class="form-select" id="specificSizeSelect" name="codeS">
    <?php
        include '../dbconnect.php';
        $stmt = $connexion->query("SELECT * FROM services");
        while ($row = $stmt->fetch()) { ?>
          <option value="<?php echo $row["codeS"]; ?>">
          <?php echo $row['nomS']; ?></option>
        <?php
          }
        ?>
    </select>
  </div>
  <div class="col-sm-3">
    <label for="codeM">Code_Ministere</label>
    <select class="form-select" id="specificSizeSelect" name="codeM">
    <?php
        include '../dbconnect.php';
        $stmt = $connexion->query("SELECT * FROM ministere");
        while ($row = $stmt->fetch()) { ?>
          <option value="<?php echo $row["codeM"]; ?>">
          <?php echo $row['codeM']; ?></option>
        <?php
          }
        ?>
    </select>
  </div>
  <div class="col-sm-3">
    <label for="dated">Date_Debut</label>
    <input type="date"  name="dated" class="form-control" id="specificSizeInputName" >
  </div>
  <div class="col-sm-3">
    <label for="datef">Date_Fin</label>
    <input type="date"  name="datef" class="form-control" id="specificSizeInputName" >
  </div>
  <div class="col-sm-3">
    <label for="budget">Budget</label>
    <input type="number" name="budget" class="form-control" id="specificSizeInputName" >
  </div>
  <br>
  <div class="col-md-6">
   <button type="submit" name="enregistrer" class="btn btn-primary">Enregistrer</button>
  </div>
</form>

<br>
<hr>

<form class="row g-3" action="rechercheRattacher.php" method="post" style=" margin:60px;" >
<div class="search">
<input type="number"  name="idA" placeholder="Recherche avec id" style=" height: 40px; margin-left: 500px;border-radius: 6px;">
  <button type="submet" name= "rechercher" style=" padding:0px;border-radius: 8px;">
    <img src="../images/images.jpeg" width="80px" height="110px"></a></button>
</div>
</form>

<hr>

<div class="table">
 <table class="table table-success table-striped table caption-top">

  <caption><h1>Liste Rattachement</h1></caption>
  <thead>
    <tr>
      <th scope="col">Id Rattachement</th>
      <th scope="col">Code Service</th>
      <th scope="col">Code Ministere</th>
      <th scope="col">Date Debut</th>
      <th scope="col">Date Fin</th>
      <th scope="col">Budget</th>
      <th scope="col">Action</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
        include "../dbconnect.php";
         $elements = $connexion->query("Select * from rattacher ");
         while ($row = $elements->fetch()){?>
         
           <tr>
             <td><?php echo $row["idR"] ;?></td>
             <td><?php echo $row["codeS"] ;?></td>
             <td><?php echo $row["codeM"] ;?></td>
             <td><?php echo $row["dated"] ;?></td>
             <td><?php echo $row["datef"] ;?></td>
             <td><?php echo $row["budget"] ;?></td>
              <td><a class="btn btn-warning"
                  href="editRattacher.php?idR=<?=$row["idR"] ?>">
                  <img src="../images/modifier.jpeg" width="30px" height="30px"></a>
              </td>
              <td><a class="btn btn-danger"
                  href="suppRattacher.php?idR=<?=$row["idR"] ?>"
                  onclick="return confirm('êtes vous sur de vouloir vraiment supprimer');">
              <img src="../images/supprimer.png" width="30px" height="30px"></a>
             </td>
           </tr>

      <?php } ?>
    </tr>
  </tbody>
</table>
</div>

</fieldset>
</div>
<script src='../js/bootstrap.min.js'></script>
</body>
</html>