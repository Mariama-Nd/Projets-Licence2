<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
<div class="table">
 <table class="table table-success table-striped table caption-top">

  <caption><h1>Nombre d'agents par ministere</h1></caption>
  <thead>
    <tr>
      <th scope="col">Ministere</th>
      <th scope="col">Nombre_Agents</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
        include "../dbconnect.php";
         $elements = $connexion->query("Select nomM ,Count(a.idA) from ministere m, rattacher r, affecter a where m.codeM=r.codeM and r.codeS=a.codeS group by nomM");
         while ($row = $elements->fetch()){?>
         
           <tr>
             <td><?php echo $row["nomM"] ;?></td>
             <td><?php echo $row["Count(a.idA)"] ;?></td>
           </tr>

      <?php } ?>
    </tr>
  </tbody>
</table>
</div>
</body>
</html>