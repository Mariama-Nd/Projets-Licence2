<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>rattacher</title>
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <link rel="stylesheet" href="../dossier/css/pages.css">
    <link rel="stylesheet" href="../dossier/css/style.css">
</head>
<body>
   <?php  include "../entete.php";?>

<div class="table">
 <table class="table table-success table-striped table caption-top">
  <thead>
    <tr>
    <th scope="col">Id Rattachement</th>
      <th scope="col">Code Service</th>
      <th scope="col">Code Ministere</th>
      <th scope="col">Date Debut</th>
      <th scope="col">Date Fin</th>
      <th scope="col">Budget</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
      
        include '../dbconnect.php';

        if (isset($_POST['rechercher'])) {

            $idR = $_POST['idR'];
            $elements = $connexion->query("Select * from rattacher WHERE idR = '". $idR . "'");
           while ($row = $elements->fetch()){?>
         
           <tr>
             <td><?php echo $row["idR"] ;?></td>
             <td><?php echo $row["codeS"] ;?></td>
             <td><?php echo $row["codeM"] ;?></td>
             <td><?php echo $row["dated"] ;?></td>
             <td><?php echo $row["datef"] ;?></td>
             <td><?php echo $row["budget"] ;?></td>
           </tr>

      <?php } }?>
    </tr>
  </tbody>
</table>
</div>
<script src='../js/bootstrap.min.js'></script>
</body>
</html>