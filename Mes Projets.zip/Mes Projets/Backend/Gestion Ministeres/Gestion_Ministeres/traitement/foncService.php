<?php
if (isset($_POST['enregistrer'])) {
    include "../dbconnect.php";

    $codeS = $_POST['codeS'];
    $nomS = $_POST['nomS'];
    $descript = $_POST['descript'];

    $q = "INSERT INTO services (codeS,nomS,descript)
        values ($codeS,'$nomS','$descript')";
    $connexion->exec($q);

    $location = $_SERVER['HTTP_REFERER'];
    if ($q) {
        header('Location: service.php');
    }
}
?>