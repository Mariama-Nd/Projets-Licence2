<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entete</title>
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
	<link rel="stylesheet" href="../dossier/css/bootsnav.css" >	
    <link rel="stylesheet" href="../dossier/css/style.css">
    <link rel="stylesheet" href="../dossier/css/responsive.css">
    <link rel="stylesheet" href="../dossier/css/info.css">
</head>
<body>
			<div class="header-area">
			    <nav class="navbar navbar-default bootsnav navbar-sticky navbar-scrollspy"  data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">

			        <div class="container">
			            <div class="navbar-header">
			                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
			                    <i class="fa fa-bars"></i>
			                </button>
			                <a class="navbar-brand">Mon<span>App</span></a>
			            </div>
						
			            <div class="collapse navbar-collapse menu-ui-design" id="navbar-menu">
			                <ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">
			                    <li class=" scroll active"><a href="../accueil.php">Accueil</a></li>
			                    <li class="scroll"><a href="?contenu=totministere">Tot_Ministere</a></li>
			                    <li class="scroll"><a href="?contenu=budgetministere">Budget_par_Ministere</a></li>
			                    <li class="scroll"><a href="?contenu=plusgrdbudget">Ministere_plus_grand_Budget</a></li>
			                    <li class="scroll"><a href="?contenu=sansbudget2023">Ministere_sans_budget</a></li>
                                <li class="scroll"><a href="" onclick='window.print();return false;'>Imprimer</a></li>
			                </ul>
			            </div>
			        </div>
			    </nav>
			</div>


            <div class='contenu'>
                <?php

                if(isset($_REQUEST['contenu']))
                {
                    $contenu=$_REQUEST['contenu'];
                    if($contenu=='totministere')
                    {
                        include("totministere.php");
                    }
                    elseif($contenu=='budgetministere')
                    {
                        include("budgetministere.php");
                    }
                    elseif($contenu=='plusgrdbudget')
                    {
                        include("plusgrdbudget.php");
                    }
                    elseif($contenu=='sansbudget2023')
                    {
                        include("sansbudget2023.php");
                    }
                    else
                    {
                         echo '<span style="color: red"> Erreur : Page introuvable </span>';
                    }
                }
                else{
                    include("accAffecter.php");
                }
                ?>
            </div>
</body>
</html>