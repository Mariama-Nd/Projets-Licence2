<?php

include '../dbconnect.php';

$r = "DELETE FROM agent WHERE idA = '" . $_GET["idA"] . "'";
$connexion->query($r);
echo $r;
if ($r) {
    $location = $_SERVER['HTTP_REFERER'];
    header('Location: agent.php?delete=1');
}
?>