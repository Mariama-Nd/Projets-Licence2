<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
<div class="table">
 <table class="table table-success table-striped table caption-top">

  <caption><h1>Ministere ayant le plus grand budget</h1></caption>
  <thead>
    <tr>
      <th scope="col">Ministere</th>
      <th scope="col">Budget</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
        include "../dbconnect.php";
         $elements = $connexion->query("Select nomM, budget from rattacher r, ministere m where r.codeM=m.codeM and budget=(select Max(budget) from rattacher)");
         while ($row = $elements->fetch()){?>
         
           <tr>
             <td><?php echo $row["nomM"] ;?></td>
             <td><?php echo $row["budget"] ;?></td>
           </tr>

      <?php } ?>
    </tr>
  </tbody>
</table>
</div>
</body>
</html>