<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>service</title>
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <link rel="stylesheet" href="../dossier/css/pages.css">
    <link rel="stylesheet" href="../dossier/css/style.css">
</head>
<body>
   <?php  include "../entete.php";?>

<div class="table">
 <table class="table table-success table-striped table caption-top">
  <thead>
    <tr>
    <th scope="col">Code Service</th>
      <th scope="col">Nom Service</th>
      <th scope="col">Description</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
      
        include '../dbconnect.php';

        if (isset($_POST['rechercher'])) {

            $codeS = $_POST['codeS'];
            $elements = $connexion->query("Select * from services WHERE codeS = '". $codeS . "'");
           while ($row = $elements->fetch()){?>
         
           <tr>
           <td><?php echo $row["codeS"] ;?></td>
             <td><?php echo $row["nomS"] ;?></td>
             <td><?php echo $row["descript"] ;?></td>
           </tr>

      <?php } }?>
    </tr>
  </tbody>
</table>
</div>
<script src='../js/bootstrap.min.js'></script>
</body>
</html>