<?php
include '../dbconnect.php';
$q = $connexion->query("SELECT * FROM agent WHERE idA='" . $_GET["idA"] . "'");

while ($row = $q->fetch(PDO::FETCH_ASSOC)) {

    $idA=$row["idA"];
    $nomA=$row["nomA"]; 
    $prenomA=$row["prenomA"]; 
    $salaire=$row["salaire"];
    $prime=$row["prime"];
}

if (isset($_POST['modifier'])) {

    $idA=$_POST["idA"];
    $nomA=$_POST["nomA"]; 
    $prenomA=$_POST["prenomA"]; 
    $salaire=$_POST["salaire"];
    $prime=$_POST["prime"];
       
    $r = "UPDATE agent SET idA='$idA',nomA='$nomA',prenomA='$prenomA',salaire='$salaire',prime='$prime'  WHERE idA = '" . $_GET["idA"] . "'";
    $connexion->exec($r);

    $location = $_SERVER['HTTP_REFERER'];
    if ($r) {
        header('Location: agent.php?success=1');
    } 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>agent</title>
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <link rel="stylesheet" href="../dossier/css/pages.css">
    <link rel="stylesheet" href="../dossier/css/style.css">

</head>
<body>
   <?php  include "../entete.php";?>
<div class="corps">
<form class="row gx-3 gy-2 align-items-center" action="" method="post">
  <div class="col-sm-3">
    <label for="idagent">Id_Agent</label>
    <input type="number" name="idA" class="form-control" id="specificSizeInputName" value="<?php echo $idA; ?>">
  </div>
  <div class="col-sm-3">
    <label for="nom">Nom_Agent</label>
    <input type="text" name="nomA" class="form-control" id="specificSizeInputName" value="<?php echo $nomA; ?>">
  </div>
  <div class="col-sm-3">
    <label for="prenom">Prenom_Agent</label>
    <input type="text"  name="prenomA" class="form-control" id="specificSizeInputName" value="<?php echo $prenomA; ?>">
  </div>
  <div class="col-sm-3">
    <label for="salaire">Salaire</label>
    <input type="number" name="salaire" class="form-control" id="specificSizeInputName" value="<?php echo $salaire; ?>">
  </div>
  <div class="col-sm-3">
    <label for="salaire">Prime</label>
    <input type="number" name="prime" class="form-control" id="specificSizeInputName" value="<?php echo $prime; ?>">
  </div>
 
  <div class="col-md-6">
   <button type="submit" name="modifier" class="btn btn-primary">Modifier</button>
  </div>
</form>
</div>
<script src='../js/bootstrap.min.js'></script>
</body>
</html>