<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Affecter</title>
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <link rel="stylesheet" href="../dossier/css/pages.css">
    <link rel="stylesheet" href="../dossier/css/style.css">
</head>
<body>
   <?php  include "../entete.php";?>
   <div class="corps">
<fieldset>
<form class="row gx-3 gy-2 align-items-center" action="foncAffecter.php" method="post">
  <div class="col-sm-3">
    <label for="numero">Numero_Affectation</label>
    <input type="number" name="numero" class="form-control" id="specificSizeInputName" >
  </div>
  <div class="col-sm-3">
    <label for="codeS">Code_Service</label>
    <select class="form-select" id="specificSizeSelect" name="codeS">
    <?php
        include '../dbconnect.php';
        $stmt = $connexion->query("SELECT * FROM services");
        while ($row = $stmt->fetch()) { ?>
          <option value="<?php echo $row["codeS"]; ?>">
          <?php echo $row['nomS']; ?></option>
        <?php
          }
        ?>
    </select>
  </div>
  <div class="col-sm-3">
    <label for="idA">Id_Agent</label>
    <select class="form-select" id="specificSizeSelect" name="idA">
    <?php
        include '../dbconnect.php';
        $stmt = $connexion->query("SELECT * FROM agent");
        while ($row = $stmt->fetch()) { ?>
          <option value="<?php echo $row["idA"]; ?>">
          <?php echo $row['nomA']; ?></option>
        <?php
          }
        ?>
    </select>
  </div>
  <div class="col-sm-3">
    <label for="dateAf">Date_Affectation</label>
    <input type="date"  name="dateAf" class="form-control" id="specificSizeInputName" >
  </div>
  <br>
  <div class="col-md-6">
   <button type="submit" name="enregistrer" class="btn btn-primary">Enregistrer</button>
  </div>
</form>
</fieldset>

<br>
<hr>

<form class="row g-3" action="rechercheAffecter.php" method="post" style=" margin:60px;" >
<div class="search">
<input type="number"  name="idA" placeholder="Recherche avec id" style=" height: 40px; margin-left: 500px;border-radius: 6px;">
  <button type="submet" name= "rechercher" style=" padding:0px;border-radius: 8px;">
    <img src="../images/images.jpeg" width="80px" height="110px"></a></button>
</div>
</form>

<hr>

<div class="table">
 <table class="table table-success table-striped table caption-top">

  <caption><h1>Liste Affectation</h1></caption>
  <thead>
    <tr>
      <th scope="col">Numero Affectation</th>
      <th scope="col">Code Service</th>
      <th scope="col">Id Agent</th>
      <th scope="col">Date Affectation</th>
      <th scope="col">Action</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
        include "../dbconnect.php";
         $elements = $connexion->query("Select * from affecter ");
         while ($row = $elements->fetch()){?>
         
           <tr>
             <td><?php echo $row["numero"] ;?></td>
             <td><?php echo $row["codeS"] ;?></td>
             <td><?php echo $row["idA"] ;?></td>
             <td><?php echo $row["dateAf"] ;?></td>
              <td><a class="btn btn-warning"
                  href="editAffecter.php?numero=<?=$row["numero"] ?>">
                  <img src="../images/modifier.jpeg" width="30px" height="30px"></a>
              </td>
              <td><a class="btn btn-danger"
                  href="suppAffecter.php?numero=<?=$row["numero"] ?>"
                  onclick="return confirm('êtes vous sur de vouloir vraiment supprimer');">
              <img src="../images/supprimer.png" width="30px" height="30px"></a>
             </td>
           </tr>

      <?php } ?>
    </tr>
  </tbody>
</table>
</div>
</fieldset>
</div>
<script src='../js/bootstrap.min.js'></script>
</body>
</html>