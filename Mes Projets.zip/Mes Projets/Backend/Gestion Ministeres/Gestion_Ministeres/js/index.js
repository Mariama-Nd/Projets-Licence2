let signUpButton = document.getElementById('signUp');
let signInButton = document.getElementById('signIn');
let container = document.getElementById('container');

signUpButton.addEventListener('click', () => {
	container.classList.add("right-panel-active");
});



signInButton.addEventListener('click', () => {
	container.classList.remove("right-panel-active");
});

/*let form = document.querySelector('form');
let email = document.getElementById('email');
let mdp = document.getElementById('mdp');

form.addEventListener("submit", (event) => {
    event.preventDefault();
	if (email.value==="" || nom.value==="") {
		email.classList.add("error");
		mdp.classList.add("error");

	}else{
		email.classList.remove("error");
		mdp.classList.remove("error");
	}	
});
email.addEventListener("change", () => {
	if (email.value==="") {
		email.classList.add("error");

	}else{
		email.classList.remove("error");
	}	

});*/
