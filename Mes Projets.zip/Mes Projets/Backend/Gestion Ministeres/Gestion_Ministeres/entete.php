<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entete</title>
    <link rel="stylesheet" href="dossier/css/bootstrap.min.css">
	<link rel="stylesheet" href="dossier/css/bootsnav.css" >	
    <link rel="stylesheet" href="dossier/css/style.css">
    <link rel="stylesheet" href="dossier/css/responsive.css">
</head>
<body>
			<div class="header-area">
			    <nav class="navbar navbar-default bootsnav navbar-sticky navbar-scrollspy"  data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">

			        <div class="container">
			            <div class="navbar-header">
			                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
			                    <i class="fa fa-bars"></i>
			                </button>
			                <a class="navbar-brand">Mon<span>App</span></a>
			            </div>
						
			            <div class="collapse navbar-collapse menu-ui-design" id="navbar-menu">
			                <ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">
			                    <li class=" scroll active"><a href="../accueil.php">Accueil</a></li>
			                    <li class="scroll"><a href="infoAgent.php">Infos_Agent</a></li>
			                    <li class="scroll"><a href="infoMinistere.php">Infos_Ministere</a></li>
			                </ul>
			            </div>
			        </div>
			    </nav>
			</div>
</body>
</html>