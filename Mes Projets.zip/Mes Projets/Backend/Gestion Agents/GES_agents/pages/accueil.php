<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>
    <link rel="stylesheet" href="accueil.css">
</head>
<body>
    <section class="sec">
        <div class="acc">
            <p>Bienvenue</p>
        </div>
    </section>
    <section class="parti">
        <form action="" class="form">
            <div class="image">
                <img src="agent.jpeg" >
            </div>
            <div class="element">
                 <h2 class="nom">Agent</h2>
                 <a href="agent.php" class="button">Ajouter</a>
            </div>
        </form>

        <form action="" class="form">
            <div class="image">
                <img src="departement.jpeg" >
            </div>
            <div class="element">
                <h2 class="nom">Departement</h2>
                <a href="departement.php" class="button">Ajouter</a>
            </div>

        </form>
        <form action="" class="form">
            <div class="image">
                <img src="stage.jpg" >
            </div>
            <div class="element">
                <h2 class="nom">Stage</h2>
                <a href="stage.php" class="button">Ajouter</a>
            </div>
        </form>

        <form action="" class="form">
            <div class="image">
                <img src="effectuer.jpeg" >
            </div>
            <div class="element">
                <h2 class="nom">Effectuer</h2>
                <a href="effectuer.php" class="button">Ajouter</a>
            </div>
        </form>
    </section>
</body>
</html>

