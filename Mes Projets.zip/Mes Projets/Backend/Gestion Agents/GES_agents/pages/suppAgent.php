<?php

include '../connexion/connexion.php';

$r = "DELETE FROM agent WHERE ida = '" . $_GET["ida"] . "'";
$connexion->query($r);
echo $r;
if ($r) {
    $location = $_SERVER['HTTP_REFERER'];
    header('Location: agent.php?delete=1');
}
?>