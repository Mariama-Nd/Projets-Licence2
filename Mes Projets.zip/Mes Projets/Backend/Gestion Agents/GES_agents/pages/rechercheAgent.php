<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>agent</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
   <?php  include "entete.php";?>

<div class="table">
 <table class="table table-success table-striped table caption-top">
  <thead>
    <tr>
      <th scope="col">Id Agent</th>
      <th scope="col">Nom</th>
      <th scope="col">Prenom</th>
      <th scope="col">Naissance</th>
      <th scope="col">Sexe</th>
      <th scope="col">Lieu</th>
      <th scope="col">Date Embauche</th>
      <th scope="col">Salaire</th>
      <th scope="col">Fonction</th>
      <th scope="col">Code Departement</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
        include 'connexion.php';
        if (isset($_POST['rechercher'])) {

            $ida = $_POST['ida'];
            $elements = $connexion->query("Select * from agent WHERE ida = '". $ida . "'");
           while ($row = $elements->fetch()){?>
         
           <tr>
             <td><?php echo $row["ida"] ;?></td>
             <td><?php echo $row["noma"] ;?></td>
             <td><?php echo $row["prenoma"] ;?></td>
             <td><?php echo $row["naissance"] ;?></td>
             <td><?php echo $row["sexe"] ;?></td>
             <td><?php echo $row["lieu"] ;?></td>
             <td><?php echo $row["dateembauche"] ;?></td>
             <td><?php echo $row["salaire"] ;?></td>
             <td><?php echo $row["Fonction"] ;?></td>
             <td><?php echo $row["coded"] ;?></td>
           </tr>

      <?php } }?>
    </tr>
  </tbody>
</table>
</div>
<script src='bootstrap.js.map'></script>
</body>
</html>