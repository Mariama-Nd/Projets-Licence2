<?php
include '../connexion/connexion.php';
$q = $connexion->query("SELECT * FROM effectuer WHERE numero='" . $_GET["numero"] . "'");

while ($row = $q->fetch(PDO::FETCH_ASSOC)) {

    $num = $row['numero'];
    $nums= $row['nums'];
    $ida = $row['ida'];
    $dated = $row['dated'];
    $datef = $row['datef'];
    $duree = $row['duree'];
}

if (isset($_POST['modifier'])) {

    $num = $_POST['num'];
    $nums= $_POST['nums'];
    $ida = $_POST['ida'];
    $dated = $_POST['dated'];
    $datef = $_POST['datef'];
    $duree = $_POST['duree'];

       
    $r = "UPDATE effectuer SET numero='$num',nums='$nums',ida='$ida',dated='$dated',datef='$datef',duree='$duree' WHERE numero = '" . $_GET["numero"] . "'";
    $connexion->exec($r);

    $location = $_SERVER['HTTP_REFERER'];
    if ($r) {
        header('Location: effectuer.php');
    } 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>effectuer</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
<?php  include "entete.php";?>
<form class="row gx-3 gy-2 align-items-center" action="" method="post">
  <div class="col-sm-3">
    <label for="numero">Numero</label>
    <input type="number" name="num" class="form-control" id="specificSizeInputName" value="<?php echo $num; ?>">
  </div>
  <div class="col-sm-3">
    <label for="nums">Numero Stage</label>
    <select class="form-select" id="specificSizeSelect" name="nums">
      <?php
        include 'connexion.php';
        $stmt = $connexion->query("SELECT * FROM stage");
        while ($row = $stmt->fetch()) { ?>
          <option value="<?php echo $row["nums"]; ?>">
          <?php echo $row['noms']; ?></option>
        <?php
          }
        ?>
    </select>
  </div>
  <div class="col-sm-3">
    <label for="ida">Id Agent</label>
    <select class="form-select" id="specificSizeSelect" name="ida">
      <?php
        include 'connexion.php';
        $stmt = $connexion->query("SELECT * FROM agent");
        while ($row = $stmt->fetch()) { ?>
          <option value="<?php echo $row["ida"]; ?>">
          <?php echo $row['noma']; ?></option>
        <?php
          }
        ?>
    </select>
  </div>
  <div class="col-sm-3">
    <label for="dated">Date Debut</label>
    <input type="date"  name="dated" class="form-control" id="specificSizeInputName" value="<?php echo $dated; ?>">
  </div>
  <div class="col-sm-3">
    <label for="datef">Date Fin</label>
    <input type="date"  name="datef" class="form-control" id="specificSizeInputName" value="<?php echo $datef; ?>">
  </div>
  <div class="col-sm-3">
    <label for="duree">Durée</label>
    <input type="number" name="duree" class="form-control" id="specificSizeInputName" value="<?php echo $duree; ?>">
  </div>
  <br>
  <div class="col-md-6">
   <button type="submit" name="modifier" class="btn btn-primary">Modifier</button>
  </div>
</form>
<script src='bootstrap.js.map'></script>
</body>
</html>

