<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>effectuer</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
<?php  include "entete.php";?>
<form class="row gx-3 gy-2 align-items-center" action="foncEffectuer.php" method="post">
  <div class="col-sm-3">
    <label for="numero">Numero</label>
    <input type="number" name="num" class="form-control" id="specificSizeInputName" >
  </div>
  <div class="col-sm-3">
    <label for="nums">Numero Stage</label>
    <select class="form-select" id="specificSizeSelect" name="nums">
      <?php
        include 'connexion.php';
        $stmt = $connexion->query("SELECT * FROM stage");
        while ($row = $stmt->fetch()) { ?>
          <option value="<?php echo $row["nums"]; ?>">
          <?php echo $row['noms']; ?></option>
        <?php
          }
        ?>
    </select>
  </div>
  <div class="col-sm-3">
    <label for="ida">Id Agent</label>
    <select class="form-select" id="specificSizeSelect" name="ida">
      <?php
        include 'connexion.php';
        $stmt = $connexion->query("SELECT * FROM agent");
        while ($row = $stmt->fetch()) { ?>
          <option value="<?php echo $row["ida"]; ?>">
          <?php echo $row['noma']; ?></option>
        <?php
          }
        ?>
    </select>
  </div>
  <div class="col-sm-3">
    <label for="dated">Date Debut</label>
    <input type="date"  name="dated" class="form-control" id="specificSizeInputName" >
  </div>
  <div class="col-sm-3">
    <label for="datef">Date Fin</label>
    <input type="date"  name="datef" class="form-control" id="specificSizeInputName" >
  </div>
  <div class="col-sm-3">
    <label for="duree">Durée</label>
    <input type="number" name="duree" class="form-control" id="specificSizeInputName" >
  </div>
  <br>
  <div class="col-md-6">
   <button type="submit" name="enregistrer" class="btn btn-primary">Enregistrer</button>
  </div>
</form>

<form class="row g-3" action="rechercheEffectuer.php" method="post" style=" margin:60px;" >
<div class="search">
<input type="number"  name="num" placeholder=" Rechercher ici" style=" height: 46px; margin-left: 500px;border-radius: 6px;">
  <button type="submet" name= "rechercher" style=" padding:0px;border-radius: 15px;">
    <img src="rechercher.jpeg" width="48px" height="45px"></a></button>
</div>
</form>

<div class="table">
 <table class="table table-success table-striped table caption-top">

  <caption><h1>Liste Effectuer</h1></caption>
  <thead>
    <tr>
      <th scope="col">Numero</th>
      <th scope="col">Numero Stage</th>
      <th scope="col">Id Agent</th>
      <th scope="col">Date Debut</th>
      <th scope="col">Date Fin</th>
      <th scope="col">Duree</th>
      <th scope="col">Action</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
        include 'connexion.php';
         $elements = $connexion->query("Select * from effectuer ");
         while ($row = $elements->fetch()){?>
         
           <tr>
             <td><?php echo $row["numero"] ;?></td>
             <td><?php echo $row["nums"] ;?></td>
             <td><?php echo $row["ida"] ;?></td>
             <td><?php echo $row["dated"] ;?></td>
             <td><?php echo $row["datef"] ;?></td>
             <td><?php echo $row["duree"] ;?></td>
              <td><a class="btn btn-warning"
                  href="actionEffectuer.php?numero=<?=$row["numero"] ?>">
                  <img src="modifier.jpeg" width="30px" height="30px"></a>
              </td>
              <td><a class="btn btn-danger"
                  href="suppEffectuer.php?numero=<?=$row["numero"] ?>"
                  onclick="return confirm('êtes vous sur de vouloir vraiment supprimer');">
              <img src="supprimer.png" width="30px" height="30px"></a>
             </td>
           </tr>

      <?php } ?>
    </tr>
  </tbody>
</table>
</div>
<script src='bootstrap.js.map'></script>
</body>
</html>