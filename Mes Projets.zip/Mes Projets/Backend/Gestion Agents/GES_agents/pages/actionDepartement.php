<?php
include '../connexion/connexion.php';
$q = $connexion->query("SELECT * FROM departement WHERE coded='" . $_GET["coded"] . "'");

while ($row = $q->fetch(PDO::FETCH_ASSOC)) {
    $coded = $row['coded'];
    $nomd = $row['nomd'];
    $localisation = $row['localisation'];
}

if (isset($_POST['modifier'])) {

    $coded = $_POST['coded'];
    $nomd = $_POST['nomd'];
    $localisation = $_POST['localisation'];



    $r = "UPDATE departement SET coded='$coded',nomd='$nomd',localisation='$localisation' WHERE coded = '" . $_GET["coded"] . "'";
    $connexion->exec($r);
    
    $location = $_SERVER['HTTP_REFERER'];
    if ($r) {
        $success = "Departement modifié avec succès...";
        header('Location: departement.php?success=1');
        echo "<script>alert($success)</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.min.css">
    <title>departement</title>
</head>
<body>
<?php  include "entete.php";?>
<form class="row g-3" action="" method="post">
  <div class="col-md-6">
    <label for="inputCity" class="form-label">Code</label>
    <input type="number" name="coded" class="form-control" id="inputCity" value="<?php echo $coded; ?>">
  </div>
  <div class="col-md-6">
    <label for="inputCity" class="form-label">Nom</label>
    <input type="text" name="nomd" class="form-control" id="inputCity" value="<?php echo $nomd; ?>">
  </div>
  <div class="col-md-6">
    <label for="inputCity" class="form-label">Localisation</label>
    <input type="text" name="localisation" class="form-control" id="inputCity" value="<?php echo $localisation; ?>">
  </div>
  <div class="col-md-6">
   <button type="submit" name="modifier" class="btn btn-primary">Modifier</button>
  </div>
</form>
<script src='bootstrap.js.map'></script>
</body>
</html>