<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recherche de stage</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
   <?php  include "entete.php";?>

<div class="table">
 <table class="table table-success table-striped table caption-top">
  <thead>
    <tr>
      <th scope="col">Numero</th>
      <th scope="col">Nom</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
        include 'connexion.php';
        if (isset($_POST['rechercher'])) {

            $nums = $_POST['nums'];
            $elements = $connexion->query("Select * from stage WHERE nums = '". $nums . "'");
           while ($row = $elements->fetch()){?>
         
           <tr>
             <td><?php echo $row["nums"] ;?></td>
             <td><?php echo $row["noms"] ;?></td>
           </tr>

      <?php } }?>
    </tr>
  </tbody>
</table>
</div>
<script src='bootstrap.js.map'></script>
</body>
</html>