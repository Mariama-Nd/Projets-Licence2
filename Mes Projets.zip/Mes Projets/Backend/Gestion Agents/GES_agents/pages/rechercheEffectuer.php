<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recherche effectuer</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
   <?php  include "entete.php";?>

<div class="table">
 <table class="table table-success table-striped table caption-top">
  <thead>
    <tr>
    <th scope="col">Numero</th>
      <th scope="col">Numero Stage</th>
      <th scope="col">Id Agent</th>
      <th scope="col">Date Debut</th>
      <th scope="col">Date Fin</th>
      <th scope="col">Duree</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
        include 'connexion.php';
        if (isset($_POST['rechercher'])) {

            $num = $_POST['num'];
            $elements = $connexion->query("Select * from effectuer WHERE numero = '". $num . "'");
           while ($row = $elements->fetch()){?>
         
           <tr>
           <td><?php echo $row["numero"] ;?></td>
             <td><?php echo $row["nums"] ;?></td>
             <td><?php echo $row["ida"] ;?></td>
             <td><?php echo $row["dated"] ;?></td>
             <td><?php echo $row["datef"] ;?></td>
             <td><?php echo $row["duree"] ;?></td>
           </tr>

      <?php } }?>
    </tr>
  </tbody>
</table>
</div>
<script src='bootstrap.js.map'></script>
</body>
</html>