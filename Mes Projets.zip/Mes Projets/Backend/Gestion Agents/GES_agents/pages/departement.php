<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.min.css">
    <title>departement</title>
</head>
<body>
<?php  include "entete.php";?>
<form class="row g-3" action="foncDepartement.php" method="post">
  <div class="col-md-6">
    <label for="inputCity" class="form-label">Code</label>
    <input type="number" name="coded" class="form-control" id="inputCity">
  </div>
  <div class="col-md-6">
    <label for="inputCity" class="form-label">Nom</label>
    <input type="text" name="nomd" class="form-control" id="inputCity">
  </div>
  <div class="col-md-6">
    <label for="inputCity" class="form-label">Localisation</label>
    <input type="text" name="localisation" class="form-control" id="inputCity">
  </div>
  <div class="col-md-6">
   <button type="submit" name="enregistrer" class="btn btn-primary">Enregistrer</button>
  </div>
</form>

<form class="row g-3" action="rechercheDepartement.php" method="post" style=" margin:60px;" >
<div class="search">
<input type="number"  name="coded" placeholder=" Rechercher ici" style=" height: 46px; margin-left: 500px;border-radius: 6px;">
  <button type="submet" name= "rechercher" style=" padding:0px;border-radius: 15px;">
    <img src="rechercher.jpeg" width="48px" height="45px"></a></button>
</div>
</form>

<div class="table">
 <table class="table table-success table-striped table caption-top">

  <caption><h1>Liste Departement</h1></caption>
  <thead>
    <tr>
      <th scope="col">Code</th>
      <th scope="col">Nom</th>
      <th scope="col">Localisation</th>
      <th scope="col">Action</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
        include 'connexion.php';
         $elements = $connexion->query("Select * from departement ");
         while ($row = $elements->fetch()){?>
         
           <tr>
             <td><?php echo $row["coded"] ;?></td>
             <td><?php echo $row["nomd"] ;?></td>
             <td><?php echo $row["localisation"] ;?></td>
             <td><a class="btn btn-warning"
                    href="actionDepartement.php?coded=<?php echo $row['coded']; ?>">
                    <img src="modifier.jpeg" width="30px" height="30px"></a></td>
             <td><a class="btn btn-danger"
                    href="suppDepartement.php?coded=<?php echo $row['coded']; ?>"
                    onclick="return confirm('êtes vous sur de vouloir vraiment supprimer');">
                    <img src="supprimer.png" width="30px" height="30px"></a>
             </td>
           </tr>

      <?php } ?>
    </tr>
  </tbody>
</table>
</div>
<script src='bootstrap.js.map'></script>
</body>
</html>