<?php
include '../connexion/connexion.php';
$q = $connexion->query("SELECT * FROM agent WHERE ida='" . $_GET["ida"] . "'");

while ($row = $q->fetch(PDO::FETCH_ASSOC)) {

    $ida = $row['ida'];
    $nom = $row['noma'];
    $prenom = $row['prenoma'];
    $naiss = $row['naissance'];
    $sexe = $row['sexe'];
    $lieu = $row['lieu'];
    $dateE = $row['dateembauche'];
    $salaire = $row['salaire'];
    $fonction = $row['fonction'];
    $coded = $row['coded'];
}

if (isset($_POST['modifier'])) {

    $ida = $_POST['ida'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $naiss = $_POST['naiss'];
    $sexe = $_POST['sexe'];
    $lieu = $_POST['lieu'];
    $dateE = $_POST['dateE'];
    $salaire = $_POST['salaire'];
    $fonction = $_POST['fonction'];
    $coded = $_POST['coded'];
       
    $r = "UPDATE agent SET ida='$ida',noma='$nom',prenoma='$prenom',naissance='$naiss',sexe='$sexe',lieu='$lieu',dateembauche='$dateE',salaire='$salaire',fonction='$fonction',coded='$coded' WHERE ida = '" . $_GET["ida"] . "'";
    $connexion->exec($r);

    $location = $_SERVER['HTTP_REFERER'];
    if ($r) {
        $success = "Agent modifié avec succès...";
        header('Location: agent.php?success=1');
        echo "<script>alert($success)</script>";
    } 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>agent</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
   <?php  include "entete.php";?>
<form class="row gx-3 gy-2 align-items-center" action="" method="post">
  <div class="col-sm-3">
    <label for="idagent">Id Agent</label>
    <input type="number" name="ida" class="form-control" id="specificSizeInputName" value="<?php echo $ida; ?>">
  </div>
  <div class="col-sm-3">
    <label for="nom">Nom</label>
    <input type="text" name="nom" class="form-control" id="specificSizeInputName" value="<?php echo $nom; ?>">
  </div>
  <div class="col-sm-3">
    <label for="prenom">Prenom</label>
    <input type="text"  name="prenom" class="form-control" id="specificSizeInputName" value="<?php echo $prenom; ?>">
  </div>
  <div class="col-sm-3">
    <label for="naissance">Naissance</label>
    <input type="date"  name="naiss" class="form-control" id="specificSizeInputName" value="<?php echo $naiss; ?>">
  </div>
  <div class="col-sm-3">
    <label for="sexe">Sexe</label>
    <input type="text"  name="sexe" class="form-control" id="specificSizeInputName" placeholder="M pour masculin et F pour féminin" value="<?php echo $sexe; ?>">
  </div>
  <div class="col-sm-3">
    <label for="lieu">Lieu Naissance</label>
    <input type="text"  name="lieu" class="form-control" id="specificSizeInputName" value="<?php echo $lieu; ?>">
  </div>
  <div class="col-sm-3">
    <label for="dateE">Date Embauche</label>
    <input type="date"  name="dateE" class="form-control" id="specificSizeInputName" value="<?php echo $dateE; ?>">
  </div>
  <div class="col-sm-3">
    <label for="salaire">Salaire</label>
    <input type="number" name="salaire" class="form-control" id="specificSizeInputName" value="<?php echo $salaire; ?>">
  </div>
  <div class="col-sm-3">
    <label for="fonction">Fonction</label>
    <input type="text"  name="fonction" class="form-control" id="specificSizeInputName" value="<?php echo $fonction; ?>">
  </div>
  <div class="col-sm-3">
    <label for="codeD">Code Departement</label>
    <select class="form-select" id="specificSizeSelect" name="coded">
    <?php
        include 'connexion.php';
        $stmt = $connexion->query("SELECT * FROM departement");
        while ($row = $stmt->fetch()) { ?>
          <option value="<?php echo $row["coded"]; ?>">
          <?php echo $row['nomd']; ?></option>
        <?php
          }
        ?>
    </select>
  </div>
  <br>
  <div class="col-md-6">
   <button type="submit" name="modifier" class="btn btn-primary">Modifier</button>
  </div>
</form>
<script src='bootstrap.js.map'></script>
</body>
</html>

