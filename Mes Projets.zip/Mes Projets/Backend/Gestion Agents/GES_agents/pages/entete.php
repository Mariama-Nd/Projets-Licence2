<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entete</title>
    <link rel="stylesheet" href="entete.css">
</head>
<body>
    <nav class="navbar navbar-light bg-light">
        <div class="nav">
            <h2 class="phrase">Pour retourner a l'accueil</h2>
            <button class="btn" type="submit"><a href="accueil.php" class="navbar-brand">Cliquer ici</a></button>
            </form>
        </div>
    </nav>

<script src='bootstrap.js.map'></script>   
</body>
</html>