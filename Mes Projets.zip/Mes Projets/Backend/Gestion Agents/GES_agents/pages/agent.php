<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>agent</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
   <?php  include "entete.php";?>
<form class="row gx-3 gy-2 align-items-center" action="foncAgent.php" method="post">
  <div class="col-sm-3">
    <label for="idagent">Id Agent</label>
    <input type="number" name="ida" class="form-control" id="specificSizeInputName" placeholder="">
  </div>
  <div class="col-sm-3">
    <label for="nom">Nom</label>
    <input type="text" name="nom" class="form-control" id="specificSizeInputName" placeholder="">
  </div>
  <div class="col-sm-3">
    <label for="prenom">Prenom</label>
    <input type="text"  name="prenom" class="form-control" id="specificSizeInputName" placeholder="">
  </div>
  <div class="col-sm-3">
    <label for="naissance">Naissance</label>
    <input type="date"  name="naiss" class="form-control" id="specificSizeInputName" placeholder="">
  </div>
  <div class="col-sm-3">
    <label for="sexe">Sexe</label>
    <input type="text"  name="sexe" class="form-control" id="specificSizeInputName" placeholder="M pour masculin et F pour féminin">
  </div>
  <div class="col-sm-3">
    <label for="lieu">Lieu Naissance</label>
    <input type="text"  name="lieu" class="form-control" id="specificSizeInputName" placeholder="">
  </div>
  <div class="col-sm-3">
    <label for="dateE">Date Embauche</label>
    <input type="date"  name="dateE" class="form-control" id="specificSizeInputName" placeholder="">
  </div>
  <div class="col-sm-3">
    <label for="salaire">Salaire</label>
    <input type="number" name="salaire" class="form-control" id="specificSizeInputName" placeholder="">
  </div>
  <div class="col-sm-3">
    <label for="fonction">Fonction</label>
    <input type="text"  name="fonction" class="form-control" id="specificSizeInputName" placeholder="">
  </div>
  <div class="col-sm-3">
    <label for="codeD">Code Departement</label>
    <select class="form-select" id="specificSizeSelect" name="coded">
    <?php
        include 'connexion.php';
        $stmt = $connexion->query("SELECT * FROM departement");
        while ($row = $stmt->fetch()) { ?>
          <option value="<?php echo $row["coded"]; ?>">
          <?php echo $row['nomd']; ?></option>
        <?php
          }
        ?>
    </select>
  </div>
  <br>
  <div class="col-md-6">
   <button type="submit" name="enregistrer" class="btn btn-primary">Enregistrer</button>
  </div>

</form>

<form class="row g-3" action="rechercheAgent.php" method="post" style=" margin:60px;" >
<div class="search">
<input type="number"  name="ida" placeholder=" Rechercher ici" style=" height: 46px; margin-left: 500px;border-radius: 6px;">
  <button type="submet" name= "rechercher" style=" padding:0px;border-radius: 15px;">
    <img src="rechercher.jpeg" width="48px" height="45px"></a></button>
</div>
</form>

<div class="table">
 <table class="table table-success table-striped table caption-top">

  <caption><h1>Liste Agents</h1></caption>
  <thead>
    <tr>
      <th scope="col">Id Agent</th>
      <th scope="col">Nom</th>
      <th scope="col">Prenom</th>
      <th scope="col">Naissance</th>
      <th scope="col">Sexe</th>
      <th scope="col">Lieu</th>
      <th scope="col">Date Embauche</th>
      <th scope="col">Salaire</th>
      <th scope="col">Fonction</th>
      <th scope="col">Code Departement</th>
      <th scope="col">Action</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
        include 'connexion.php';
         $elements = $connexion->query("Select * from agent ");
         while ($row = $elements->fetch()){?>
         
           <tr>
             <td><?php echo $row["ida"] ;?></td>
             <td><?php echo $row["noma"] ;?></td>
             <td><?php echo $row["prenoma"] ;?></td>
             <td><?php echo $row["naissance"] ;?></td>
             <td><?php echo $row["sexe"] ;?></td>
             <td><?php echo $row["lieu"] ;?></td>
             <td><?php echo $row["dateembauche"] ;?></td>
             <td><?php echo $row["salaire"] ;?></td>
             <td><?php echo $row["Fonction"] ;?></td>
             <td><?php echo $row["coded"] ;?></td>
             <td><a class="btn btn-warning"
                    href="actionAgent.php?ida=<?php echo $row['ida']; ?>">
                    <img src="modifier.jpeg" width="30px" height="30px"></a></td>
             <td><a class="btn btn-danger"
                    href="suppAgent.php?ida=<?php echo $row['ida']; ?>"
                    onclick="return confirm('êtes vous sur de vouloir vraiment supprimer');">
                    <img src="supprimer.png" width="30px" height="30px"></a>
             </td>
           </tr>

      <?php } ?>
    </tr>
  </tbody>
</table>
</div>
<script src='bootstrap.js.map'></script>
</body>
</html>