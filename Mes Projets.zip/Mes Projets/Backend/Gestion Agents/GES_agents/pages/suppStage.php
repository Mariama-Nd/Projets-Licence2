<?php

include '../connexion/connexion.php';

$r = "DELETE FROM stage WHERE nums = '" . $_GET["nums"] . "'";
$connexion->query($r);
echo $r;
if ($r) {
    $location = $_SERVER['HTTP_REFERER'];
    header('Location: stage.php');
}
?>