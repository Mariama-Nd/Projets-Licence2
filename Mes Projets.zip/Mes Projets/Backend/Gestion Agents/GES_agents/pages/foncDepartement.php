<?php
if (isset($_POST['enregistrer'])) {
    include 'connexion.php';

    $coded = $_POST['coded'];
    $nomd = $_POST['nomd'];
    $localisation = $_POST['localisation'];

    $q = "INSERT INTO departement (coded,nomd,localisation) 
        values ($coded,'$nomd','$localisation')";
    $connexion->exec($q);

    $location = $_SERVER['HTTP_REFERER'];
    if ($q) {
        $success = "departement ajouté avec succès...";
        header('Location: departement.php?success=1');
    }
}
?>