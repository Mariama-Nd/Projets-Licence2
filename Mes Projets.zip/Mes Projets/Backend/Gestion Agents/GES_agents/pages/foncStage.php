<?php
if (isset($_POST['enregistrer'])) {
    include 'connexion.php';

    $nums = $_POST['nums'];
    $noms = $_POST['noms'];

    $q = "INSERT INTO stage(nums,noms) 
        values ($nums,'$noms')";
    $connexion->exec($q);

    $location = $_SERVER['HTTP_REFERER'];
    if ($q) {
        $success = "stage ajouté avec succès...";
        header('Location: stage.php?success=1');
    }
}
?>