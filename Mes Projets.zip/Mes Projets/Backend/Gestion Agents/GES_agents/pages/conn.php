<?php
session_start();
include 'connexion.php';
if (isset($_SESSION['email'])) {
    header('Location: accueil.php');
}
if (isset($_POST['valider'])) {
    if (!empty($_POST['email']) && !empty($_POST['mdp'])) {
      
        $email=$_POST['email'];
        $mdp=$_POST['mdp'];
        $q=("SELECT * FROM users WHERE email='$email' and mdp='$mdp'");
       $result =mysqli_query($connexion,$q)
       

       
        if (mysqli_num_rows($result)>0) {

            $_SESSION['logged_in']=true;
            header('Location: index.php');
            exit();

        }else {
            echo 'email ou pass incorrect';
            header('Location: accueil.php');
            exit();

        }

    }else{

        $message="Veuillez remplir tout les champs";
    }
    
}
?>