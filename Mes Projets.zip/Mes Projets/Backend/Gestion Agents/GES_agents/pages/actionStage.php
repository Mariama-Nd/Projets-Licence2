<?php
include '../connexion/connexion.php';
$q = $connexion->query("SELECT * FROM stage WHERE nums='" . $_GET["nums"] . "'");

while ($row = $q->fetch(PDO::FETCH_ASSOC)) {
    $nums = $row['nums'];
    $noms = $row['noms'];
}

if (isset($_POST['modifier'])) {

    $nums = $_POST['nums'];
    $noms = $_POST['noms'];


    $r = "UPDATE stage SET nums='$nums',noms='$noms' WHERE nums = '" . $_GET["nums"] . "'";
    $connexion->exec($r);
    
    $location = $_SERVER['HTTP_REFERER'];
    if ($r) {
        $success = "Stage modifié avec succès...";
        header('Location: stage.php?success=1');
        echo "<script>alert($success)</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.min.css">
    <title>Stage</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
<?php  include "entete.php";?>
<form class="row g-3" action="" method="post">
  <div class="col-md-6">
    <label for="inputCity" class="form-label">Numero Stage</label>
    <input type="number" name="nums" class="form-control" id="inputCity" value="<?php echo $nums; ?>">
  </div>
  <div class="col-md-6">
    <label for="inputCity" class="form-label">Nom Stage</label>
    <input type="text" name="noms" class="form-control" id="inputCity" value="<?php echo $noms; ?>">
  </div>
  <div class="col-md-6">
   <button type="submit" name="modifier" class="btn btn-primary">Modifier</button>
  </div>
</form>
<script src='bootstrap.js.map'></script>
</body>
</html>