<?php

include '../connexion/connexion.php';

$r = "DELETE FROM departement WHERE coded = '" . $_GET["coded"] . "'";
$connexion->query($r);
echo $r;
if ($r) {
    $location = $_SERVER['HTTP_REFERER'];
    header('Location: departement.php?delete=1');
}
?>