<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recherche de departement</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
   <?php  include "entete.php";?>

<div class="table">
 <table class="table table-success table-striped table caption-top">
  <thead>
    <tr>
    <th scope="col">Code</th>
      <th scope="col">Nom</th>
      <th scope="col">Localisation</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
        include 'connexion.php';
        if (isset($_POST['rechercher'])) {

            $coded = $_POST['coded'];
            $elements = $connexion->query("Select * from departement WHERE coded = '". $coded . "'");
           while ($row = $elements->fetch()){?>
         
           <tr>
           <td><?php echo $row["coded"] ;?></td>
             <td><?php echo $row["nomd"] ;?></td>
             <td><?php echo $row["localisation"] ;?></td>
           </tr>

      <?php } }?>
    </tr>
  </tbody>
</table>
</div>
<script src='bootstrap.js.map'></script>
</body>
</html>