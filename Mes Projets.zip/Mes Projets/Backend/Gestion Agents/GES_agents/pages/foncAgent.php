<?php
if (isset($_POST['enregistrer'])) {
    include 'connexion.php';

    $ida = $_POST['ida'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $naiss = $_POST['naiss'];
    $sexe = $_POST['sexe'];
    $lieu = $_POST['lieu'];
    $dateE = $_POST['dateE'];
    $salaire = $_POST['salaire'];
    $fonction = $_POST['fonction'];
    $coded = $_POST['coded'];

    $q = "INSERT INTO agent (ida,noma,prenoma,naissance,sexe,lieu,dateembauche,salaire,fonction,coded) 
        values ($ida,'$nom','$prenom','$naiss','$sexe','$lieu','$dateE',$salaire,'$fonction',$coded)";
    $connexion->exec($q);

    $location = $_SERVER['HTTP_REFERER'];
    if ($q) {
        $success = "agent ajouté avec succès...";
        header('Location: agent.php?success=1');
    }
}
?>