<?php
if (isset($_POST['enregistrer'])) {
    include 'connexion.php';

    $num = $_POST['num'];
    $nums = $_POST['nums'];
    $ida = $_POST['ida'];
    $dated = $_POST['dated'];
    $datef = $_POST['datef'];
    $duree = $_POST['duree'];

    $q = "INSERT INTO effectuer values ('$num','$nums','$ida','$dated','$datef','$duree')";
    $connexion->exec($q);

    $location = $_SERVER['HTTP_REFERER'];
    if ($q) {
        header('Location: effectuer.php?success=1');
    }
}
?>