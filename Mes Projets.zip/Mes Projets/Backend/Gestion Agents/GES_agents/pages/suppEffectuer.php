<?php

include '../connexion/connexion.php';

$r = "DELETE FROM effectuer WHERE numero = '" . $_GET["numero"] . "'";
$connexion->query($r);
if ($r) {
    $location = $_SERVER['HTTP_REFERER'];
    header('Location: effectuer.php');
}
?>