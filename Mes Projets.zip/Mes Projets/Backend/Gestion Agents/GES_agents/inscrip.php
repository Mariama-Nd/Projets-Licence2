<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire de connexion</title>
    <link rel="stylesheet" href="inscrip.css">
</head>
<body>
   <section>
       <h1> Inscription</h1>
       <form action="" method="POST"> 
           <label>Adresse Mail</label>
           <input type="email" name="email">
           <label >Mots de Passe</label>
           <input type="password" name="mdp">
           <input type="submit" value="Valider" name="valider">
       </form>
   </section> 
</body>
</html>
<?php 
    include 'connexion.php';
    if(isset($_POST['valider'])) {

        $email=$_POST['email'];
        $mdp=$_POST['mdp'];

        $q = "INSERT INTO users (email,mdp) values ('$email','$mdp')";
        $connexion->exec($q);

        $location = $_SERVER['HTTP_REFERER'];
       if ($q) {
            echo '<script>alert("inscription avec succes")</script>';
            header('Location: index.php');
        }
    }
?>