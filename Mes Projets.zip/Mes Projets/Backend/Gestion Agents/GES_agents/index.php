
<?php
session_start();
include 'pages/connexion.php';



if (isset($_POST['valider'])) {
    if (!empty($_POST['email']) && !empty($_POST['mdp'])) {
        
        $email = $_POST['email'];
        $mdp = $_POST['mdp'];

        $q = "SELECT * FROM users WHERE email = ? AND mdp = ?";
        $stmt = $connexion->prepare($q);
        $stmt->execute([$email, $mdp]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $_SESSION['email'] = $email;
            header('Location: pages/accueil.php');
            exit();
        } else {
            echo 'Email ou mot de passe incorrect';
        }
    } else {
        $message = "Veuillez remplir tous les champs";
        echo $message;
        header('Location: index.php');
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire de connexion</title>
    <link rel="stylesheet" href="inscrip.css">
</head>
<body>
   <section>
       <h1> Connexion</h1>
       <form method="POST" action=""> 
           <label>Adresse Mail</label>
           <input type="email" name="email">
           <label >Mots de Passe</label>
           <input type="password" name="mdp">
           <input type="submit" value="Valider" name="valider">
           <br> <p> <?php
           if (isset($message)) {
            echo $message ;
          }  ?> </p>
           <p>Pas encore de compte ?? <a href="inscrip.php">S'inscrire</a></p>
       </form>
   </section> 
</body>
</html>

