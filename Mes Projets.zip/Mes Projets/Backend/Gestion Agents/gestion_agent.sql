-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : mar. 25 juin 2024 à 17:04
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gestion_agent`
--

-- --------------------------------------------------------

--
-- Structure de la table `agent`
--

CREATE TABLE `agent` (
  `ida` int(11) NOT NULL,
  `noma` varchar(50) DEFAULT NULL,
  `prenoma` varchar(50) DEFAULT NULL,
  `naissance` date DEFAULT NULL,
  `sexe` char(1) DEFAULT NULL,
  `lieu` varchar(60) DEFAULT NULL,
  `dateembauche` date DEFAULT NULL,
  `salaire` int(11) DEFAULT NULL,
  `fonction` varchar(60) DEFAULT NULL,
  `coded` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `agent`
--

INSERT INTO `agent` (`ida`, `noma`, `prenoma`, `naissance`, `sexe`, `lieu`, `dateembauche`, `salaire`, `fonction`, `coded`) VALUES
(1, 'zdeg', 'ccs', '2024-05-14', 'M', 'svwz', '2024-05-27', 1122333, 'wdzwsfs', 1);

-- --------------------------------------------------------

--
-- Structure de la table `departement`
--

CREATE TABLE `departement` (
  `coded` int(11) NOT NULL,
  `nomd` varchar(50) NOT NULL,
  `localisation` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `departement`
--

INSERT INTO `departement` (`coded`, `nomd`, `localisation`) VALUES
(1, 'informatique', 'Guediawaye'),
(2, 'Ressource Humaine', 'Pikine');

-- --------------------------------------------------------

--
-- Structure de la table `effectuer`
--

CREATE TABLE `effectuer` (
  `numero` int(11) NOT NULL,
  `nums` int(11) DEFAULT NULL,
  `ida` int(11) DEFAULT NULL,
  `dated` date DEFAULT NULL,
  `datef` date DEFAULT NULL,
  `duree` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `effectuer`
--

INSERT INTO `effectuer` (`numero`, `nums`, `ida`, `dated`, `datef`, `duree`) VALUES
(1, 2, 1, '2024-05-17', '2024-05-15', 10),
(2, 1, 1, '2023-08-10', '2024-05-20', 3);

-- --------------------------------------------------------

--
-- Structure de la table `stage`
--

CREATE TABLE `stage` (
  `nums` int(11) NOT NULL,
  `noms` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `stage`
--

INSERT INTO `stage` (`nums`, `noms`) VALUES
(1, 'informatique'),
(2, 'ydsfe'),
(3, 'zdsgz');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `email` varchar(30) NOT NULL,
  `mdp` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`email`, `mdp`) VALUES
('abcde12@gmail.com', '@qwert1234'),
('mama@gmail.com', '12345');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `agent`
--
ALTER TABLE `agent`
  ADD PRIMARY KEY (`ida`),
  ADD KEY `coded` (`coded`);

--
-- Index pour la table `departement`
--
ALTER TABLE `departement`
  ADD PRIMARY KEY (`coded`);

--
-- Index pour la table `effectuer`
--
ALTER TABLE `effectuer`
  ADD PRIMARY KEY (`numero`),
  ADD KEY `nums` (`nums`),
  ADD KEY `ida` (`ida`);

--
-- Index pour la table `stage`
--
ALTER TABLE `stage`
  ADD PRIMARY KEY (`nums`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`email`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `agent`
--
ALTER TABLE `agent`
  ADD CONSTRAINT `agent_ibfk_1` FOREIGN KEY (`coded`) REFERENCES `departement` (`coded`);

--
-- Contraintes pour la table `effectuer`
--
ALTER TABLE `effectuer`
  ADD CONSTRAINT `effectuer_ibfk_1` FOREIGN KEY (`nums`) REFERENCES `stage` (`nums`),
  ADD CONSTRAINT `effectuer_ibfk_2` FOREIGN KEY (`ida`) REFERENCES `agent` (`ida`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
