<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header('Access-Control-Allow-Credentials: true');
header("Access-Control-Allow-Methods: *");
header('Content-Type: application/json');

try {
    // Connexion à la base de données
    $dsn = 'mysql:host=localhost;dbname=BD_topcas;charset=utf8';
    $username = 'root';
    $password = '';
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ];

    $pdo = new PDO($dsn, $username, $password, $options);

    // Vérification si les données POST sont présentes
    if (isset($_POST['user']) && isset($_POST['messages'])) {
        $nomUtilisateur = $_POST['user'];
        $messages = $_POST['messages'];

        // Insertion du message dans la base de données
        $stmt = $pdo->prepare("INSERT INTO cas (nomUtilisateur, messages) VALUES (:nomUtilisateur, :messages)");
        $stmt->execute([':nomUtilisateur' => $nomUtilisateur, ':messages' => $messages]);

        // Réponse JSON en cas de succès
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Données POST manquantes']);
    }

} catch (PDOException $e) {
    // Réponse JSON en cas d'erreur
    echo json_encode(['success' => false, 'message' => 'Erreur lors de l\'insertion du message: ' . $e->getMessage()]);
}
?>