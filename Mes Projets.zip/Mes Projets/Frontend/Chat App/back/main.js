//Fonction mode nuit

let div_interface = document.getElementById('interface')
let btn = document.getElementById('btn')
let body = document.getElementById('body')
function mode_j_n() {
    if (div_interface.style.backgroundColor == '' || div_interface.style.backgroundColor == 'rgba(205, 239, 207, 0.941)') {
        div_interface.style.backgroundColor = 'black'
        btn.innerHTML = 'Mode Jour'
        body.style.backgroundImage = "url('images.jpeg')";
    } else {
        div_interface.style.backgroundColor = 'rgba(205, 239, 207, 0.941)'
        btn.innerHTML = 'Mode Nuit'
        body.style.backgroundImage = "";
    }
}

//Fonction pour afficher les messages

function afficheMessages() {
    $.ajax({
        url: "http://localhost/back/get.php",
        method: "GET",
        success: function(response) {
            if (response.success) {
                $('#contenu').empty();
                response.messages.forEach(msg => {
                    $('#contenu').append(`
                        <div class="message" id="mess" style="background-color: #fff; padding-left:10px">
                            <strong>${msg.nomUtilisateur}</strong>: ${msg.messages}
                            <div class="temps">${msg.temps}</div>
                        </div>
                    `);
                });
            } else {
                console.error("Erreur lors de la récupération des messages:", response.message);
            }
        },
        error: function() {
            console.error("Erreur lors de la requête AJAX");
        }
    });
}

//Fonction pour envoyer les messages

function sendMessage() {

    let user_input = document.getElementById("username");
    let messages_input = document.getElementById("message");
    let user = user_input.value;
    let messages = messages_input.value;

    let xhr = new XMLHttpRequest();
    xhr.open("POST", "http://localhost/back/send.php");
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.onload = function() {
        let response_json = JSON.parse(xhr.responseText);
        console.log(response_json);
        if (response_json.success) {
            afficheMessages(); // Recharger les messages après l'envoi
            
        } else {
            alert("Erreur: " + response_json.message);
        }
    };
//on encode les données pour gerer les caracteres speciaux
    let data = `user=${encodeURIComponent(user)}&messages=${encodeURIComponent(messages)}`;
//et on les envoie au serveur via la methode post precisee dans les parametres
    xhr.send(data);

}

//Fonction pour afficher les notifications
function avoirNotification() {
    Notification.requestPermission(function() {
        if (Notification.permission === "granted") {
            new Notification("Notification", { body: "Nouveau Message" });
        } else {
            console.log("Les notifications ne sont pas autorisées!!!");
        }
    });
}


