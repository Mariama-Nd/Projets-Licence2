<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header('Access-Control-Allow-Credentials: true');
header("Access-Control-Allow-Methods: *");
header('Content-Type: application/json');

try {
    // Connexion à la base de données
    $dsn = 'mysql:host=localhost;dbname=BD_topcas;charset=utf8';
    $username = 'root';
    $password = '';
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ];
    
    $pdo = new PDO($dsn, $username, $password, $options);

    // Récupération des messages depuis la base de données
    $q = $pdo->query("SELECT id, nomUtilisateur, messages, temps FROM cas ORDER BY temps DESC");
    $elements = $q->fetchAll();

    // Réponse JSON en cas de succès
    echo json_encode(['success' => true, 'messages' => $elements]);//on envoie la reponse sous format json

} catch (PDOException $e) {
    // Réponse JSON en cas d'erreur
    echo json_encode(['success' => false, 'messages' => 'Erreur lors de la récupération des messages: ' . $e->getMessage()]);
}
?>
