<!doctype html>
<html class="no-js" lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
        <title>Gestion des Ministeres</title>
        <link rel="stylesheet" href="dossier/css/bootstrap.min.css">
		<link rel="stylesheet" href="dossier/css/bootsnav.css" >	
        <link rel="stylesheet" href="dossier/css/style.css">
        <link rel="stylesheet" href="dossier/css/responsive.css">
        
    </head>
	
	<body>
		<section class="top-area">
			<div class="header-area">
			    <nav class="navbar navbar-default bootsnav navbar-sticky navbar-scrollspy"  data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">

			        <div class="container">
			            <div class="navbar-header">
			                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
			                    <i class="fa fa-bars"></i>
			                </button>
			                <a class="navbar-brand">Mon<span>App</span></a>
			            </div>
						
			            <div class="collapse navbar-collapse menu-ui-design" id="navbar-menu">
			                <ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">
			                    <li class="scroll"><a href="traitement/agent.php">Agent</a></li>
			                    <li class="scroll"><a href="traitement/affecter.php">Affecter</a></li>
			                    <li class="scroll"><a href="traitement/service.php">Service</a></li>
			                    <li class="scroll"><a href="traitement/rattacher.php">Rattacher</a></li>
			                    <li class="scroll"><a href="traitement/ministere.php">Ministere</a></li>
			                </ul>
			            </div>
			        </div>
			    </nav>
			</div>

	    <div class="clearfix"></div>
		</section>
		<section id="home" class="welcome-hero">
			<div class="container">
				<div class="welcome-hero-txt">
				<h2><a href="deconnect.php">Se Deconnecter</a></h2>
					<h2>Gestion Des Ministeres <br>all you need </h2>
					<br><br><br><br><br>
				</div>
				<div class="welcome-hero-serch-box">		
			</div>
		<section id="list-topics" class="list-topics">
			<div class="container">
				<div class="list-topics-content">
					<ul>
						<li>
							<div class="single-list-topics-content">
								<h2><a href="traitement/agent.php">Agent</a></h2>
							</div>
						</li>
						<li>
							<div class="single-list-topics-content">
								<h2><a href="traitement/affecter.php">Affecter</a></h2>
							</div>
						</li>
						<li>
							<div class="single-list-topics-content">
								<h2><a href="traitement/service.php">Service</a></h2>
							</div>
						</li>
						<li>
							<div class="single-list-topics-content">
								<h2><a href="traitement/rattacher.php">Rattacher</a></h2>
							</div>
						</li>
						<li>
							<div class="single-list-topics-content">
								<h2><a href="traitement/ministere.php">Ministere</a></h2>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</section>  
        
    </body>
	
</html>