<?php
//ici je gere l'inscription
session_start();
include 'dbconnect.php';
if (isset($_POST['valider'])) {
    if (!empty($_POST['nom']) && !empty($_POST['email']) && !empty($_POST['pass'])) {

		$nom=htmlspecialchars($_POST['nom']);
		$email=htmlspecialchars($_POST['email']);
		$pass=sha1($_POST['pass']);

		$insert = $connexion->prepare("INSERT INTO users VALUES(?,?,?)");
		$q=$insert->execute(array($email,$nom,$pass));
		if ($q) {
			header('Location: index.php');
			echo '<script>alert("Insertion reussie")</script>';
	    }
		
	}else{
		echo '<script>alert("veuillez remplir tout les champs")</script>';
	}
}

//ici je gere l'authentification
if (isset($_POST['connecter'])) {
if (!empty($_POST['email']) && !empty($_POST['pass'])) {

	    $email=htmlspecialchars($_POST['email']);
	    $pass=sha1($_POST['pass']);


		$select = $connexion->prepare("SELECT * FROM users WHERE email = ? AND pass = ?");
		$select->execute(array($email,$pass));
		if ($select->rowCount()>0) {
			$_SESSION['email'] = $email;
			header('Location: accueil.php');
			exit();
            
        } else {
			echo '<script>alert("Email ou mot de passe incorrect")</script>';
			header('Location: index.php');
        }
    } else {
        echo '<script>alert("veuillez remplir tout les champs")</script>';
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <title>Connexion</title>
</head>
<body>
<h2 style="font-size: 50px;">Connexion/Inscription</h2>
<div class="container" id="container">
	<div class="form-container sign-up-container">
		<form action="" method="post">
			<h1>Créer un Compte</h1>
			<input type="text" name="nom" placeholder="Nom" />
			<input type="email" name="email" placeholder="Email" />
			<input type="password" name="pass" placeholder="Mot de pass"/>
			<button name="valider">Valider</button>
		</form>
	</div>
	<div class="form-container sign-in-container">
		<form method="post" action="">
			<h1>Se Connecter</h1>
			<input type="email" name="email" id="email" placeholder="Email" />
			<input type="password" name="pass" id="mdp" placeholder="Mot de pass" />
			<button name="connecter" >Se Connecter</button>
		</form>
	</div>
	<div class="overlay-container">
		<div class="overlay">
			<div class="overlay-panel overlay-left">
				<h1>De Retour !!</h1>
				<p>Veuillez vous connectez a votre compte</p>
				<button class="ghost" id="signIn">Se Connecter</button>
			</div>
			<div class="overlay-panel overlay-right">
				<h1>Salue !!</h1>
				<p>Veuillez entrer vos détails personnels</p>
				<button class="ghost" id="signUp">S'inscrire</button>
			</div>
		</div>
	</div>
</div>
<script src="js/index.js"></script>
</body>
</html>