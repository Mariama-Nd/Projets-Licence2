<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service</title>
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <link rel="stylesheet" href="../dossier/css/pages.css">
    <link rel="stylesheet" href="../dossier/css/style.css">
</head>
<body>
   <?php include "../entete.php";?>
   <div class="corps">
<fieldset>
<form class="row gx-3 gy-2 align-items-center" action="foncService.php" method="post">
  <div class="col-sm-3">
    <label for="codeS">Code_Service</label>
    <input type="number" name="codeS" class="form-control" id="specificSizeInputName" >
  </div>
  <div class="col-sm-3">
    <label for="nom">Nom_Service</label>
    <input type="text" name="nomS" class="form-control" id="specificSizeInputName" >
  </div>
  <div class="col-sm-3">
    <label for="prenom">Description</label>
    <input type="text"  name="descript" class="form-control" id="specificSizeInputName" >
  </div>
  <br>
  <div class="col-md-6">
   <button type="submit" name="enregistrer" class="btn btn-primary">Enregistrer</button>
  </div>
</form>
</fieldset>

<br>
<hr>

<form class="row g-3" action="rechercheService.php" method="post" style=" margin:60px;" >
<div class="search">
<input type="number"  name="idA" placeholder="Recherche avec id" style=" height: 40px; margin-left: 500px;border-radius: 6px;">
  <button type="submet" name= "rechercher" style=" padding:0px;border-radius: 8px;">
    <img src="../images/images.jpeg" width="80px" height="110px"></a></button>
</div>
</form>

<hr>

<div class="table">
 <table class="table table-success table-striped table caption-top">

  <caption><h1>Liste Services</h1></caption>
  <thead>
    <tr>
      <th scope="col">Code Service</th>
      <th scope="col">Nom Service</th>
      <th scope="col">Description</th>
      <th scope="col">Action</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
        include "../dbconnect.php";
         $elements = $connexion->query("Select * from services ");
         while ($row = $elements->fetch()){?>
         
           <tr>
             <td><?php echo $row["codeS"] ;?></td>
             <td><?php echo $row["nomS"] ;?></td>
             <td><?php echo $row["descript"] ;?></td>
              <td><a class="btn btn-warning"
                  href="editService.php?codeS=<?php echo $row['codeS']; ?>">
                  <img src="../images/modifier.jpeg" width="30px" height="30px"></a>
              </td>
              <td><a class="btn btn-danger"
                  href="suppService.php?codeS=<?php echo $row['codeS']; ?>"
                  onclick="return confirm('êtes vous sur de vouloir vraiment supprimer');">
              <img src="../images/supprimer.png" width="30px" height="30px"></a>
             </td>
           </tr>

      <?php } ?>
    </tr>
  </tbody>
</table>
</div>
</fieldset>
</div>
<script src='../js/bootstrap.min.js'></script>
</body>
</html>