<?php
if (isset($_POST['enregistrer'])) {
    include "../dbconnect.php";

    $numero = $_POST['numero'];
    $codeS = $_POST['codeS'];
    $idA = $_POST['idA'];
    $dateAf = $_POST['dateAf'];

    $q = "INSERT INTO affecter (numero,codeS,idA,dateAf)
        values ($numero,$codeS,$idA,'$dateAf')";
    $connexion->exec($q);

    $location = $_SERVER['HTTP_REFERER'];
    if ($q) {
        header('Location: affecter.php');
        
    }
}
?>