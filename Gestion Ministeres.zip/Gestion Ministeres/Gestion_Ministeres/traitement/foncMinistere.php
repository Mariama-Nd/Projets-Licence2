<?php
if (isset($_POST['enregistrer'])) {
    include "../dbconnect.php";

    $codeM = $_POST['codeM'];
    $nomM = $_POST['nomM'];

    $q = "INSERT INTO ministere (codeM,nomM)
        values ($codeM,'$nomM')";
    $connexion->exec($q);

    $location = $_SERVER['HTTP_REFERER'];
    if ($q) {
        header('Location: ministere.php');
    }
}
?>