<?php

include '../dbconnect.php';

$r = "DELETE FROM affecter WHERE numero = '" . $_GET["numero"] . "'";
$connexion->query($r);
echo $r;
if ($r) {
    $location = $_SERVER['HTTP_REFERER'];
    header('Location: affecter.php?delete=1');
}
?>