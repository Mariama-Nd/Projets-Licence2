<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>affecter</title>
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <link rel="stylesheet" href="../dossier/css/pages.css">
    <link rel="stylesheet" href="../dossier/css/style.css">
</head>
<body>
   <?php  include "../entete.php";?>

<div class="table">
 <table class="table table-success table-striped table caption-top">
  <thead>
    <tr>
    <th scope="col">Numero Affectation</th>
      <th scope="col">Code Service</th>
      <th scope="col">Id Agent</th>
      <th scope="col">Date Affectation</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
      
        include '../dbconnect.php';

        if (isset($_POST['rechercher'])) {

            $numero = $_POST['numero'];
            $elements = $connexion->query("Select * from affecter WHERE numero = '". $numero . "'");
           while ($row = $elements->fetch()){?>
         
           <tr>
           <td><?php echo $row["numero"] ;?></td>
             <td><?php echo $row["codeS"] ;?></td>
             <td><?php echo $row["idA"] ;?></td>
             <td><?php echo $row["dateAf"] ;?></td>
           </tr>

      <?php } }?>
    </tr>
  </tbody>
</table>
</div>
<script src='../js/bootstrap.min.js'></script>
</body>
</html>