<?php
include '../dbconnect.php';
$q = $connexion->query("SELECT * FROM ministere WHERE codeM='" . $_GET["codeM"] . "'");

while ($row = $q->fetch(PDO::FETCH_ASSOC)) {

    $codeM = $row['codeM'];
    $nomM = $row['nomM'];
}

if (isset($_POST['modifier'])) {

    $codeM = $_POST['codeM'];
    $nomM = $_POST['nomM'];
       
    $r = "UPDATE ministere SET codeM='$codeM',nomM='$nomM'  WHERE codeM = '" . $_GET["codeM"] . "'";
    $connexion->exec($r);

    $location = $_SERVER['HTTP_REFERER'];
    if ($r) {
        header('Location: ministere.php?success=1');
    } 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ministere</title>
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
     <link rel="stylesheet" href="../dossier/css/pages.css">
    <link rel="stylesheet" href="../dossier/css/style.css">
</head>
<body>
   <?php  include "../entete.php";?>
  <div class="corps">
<fieldset>
<form class="row gx-3 gy-2 align-items-center" action="" method="post">
  <div class="col-sm-3">
    <label for="idagent">Code_Ministere</label>
    <input type="number" name="codeM" class="form-control" id="specificSizeInputName" value="<?php echo $codeM; ?>">
  </div>
  <div class="col-sm-3">
    <label for="nom">Nom_Ministere</label>
    <input type="text" name="nomM" class="form-control" id="specificSizeInputName" value="<?php echo $nomM; ?>">
  </div>
  <br>
  <div class="col-md-6">
   <button type="submit" name="modifier" class="btn btn-primary">Modifier</button>
  </div>
</form>
</fieldset>

<hr>
</fieldset>
</div>
<script src='../js/bootstrap.min.js'></script>
</body>
</html>

