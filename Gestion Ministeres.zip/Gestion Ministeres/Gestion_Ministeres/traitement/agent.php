<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>agent</title>
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <link rel="stylesheet" href="../dossier/css/pages.css">
    <link rel="stylesheet" href="../dossier/css/style.css">

</head>
<body>
   <?php  include "../entete.php";?>
<div class="corps">
<fieldset>
<div class="form">
<form class="row gx-3 gy-2 align-items-center" action="foncAgent.php" method="post">
  <div class="col-sm-3">
    <label for="idagent">Id_Agent</label>
    <input type="number" name="idA" class="form-control" id="specificSizeInputName" >
  </div>
  <div class="col-sm-3">
    <label for="nom">Nom_Agent</label>
    <input type="text" name="nomA" class="form-control" id="specificSizeInputName" >
  </div>
  <div class="col-sm-3">
    <label for="prenom">Prenom_Agent</label>
    <input type="text"  name="prenomA" class="form-control" id="specificSizeInputName" >
  </div>
  <div class="col-sm-3">
    <label for="salaire">Salaire</label>
    <input type="number" name="salaire" class="form-control" id="specificSizeInputName" >
  </div>
  <div class="col-sm-3">
    <label for="salaire">Prime</label>
    <input type="number" name="prime" class="form-control" id="specificSizeInputName" >
  </div>
 
  <div class="col-md-6">
   <button type="submit" name="enregistrer" class="btn btn-primary">Enregistrer</button>
  </div>
</form>
</div>
<br>

<hr>

<form class="row g-3" action="rechercheAgent.php" method="post" style=" margin:60px;" >
<div class="search">
<input type="number"  name="idA" placeholder="Recherche avec id" style=" height: 40px; margin-left: 500px;border-radius: 6px;">
  <button type="submet" name= "rechercher" style=" padding:0px;border-radius: 8px;">
    <img src="../images/images.jpeg" width="80px" height="110px"></a></button>
</div>
</form>

<hr>

<div class="table">
 <table class="table table-success table-striped table caption-top">

  <caption><h1>Liste Agents</h1></caption>
  <thead>
    <tr>
      <th scope="col">Id Agent</th>
      <th scope="col">Nom Agent</th>
      <th scope="col">Prenom Agent</th>
      <th scope="col">Salaire</th>
      <th scope="col">Prime</th>
      <th scope="col">Action</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
        include "../dbconnect.php";
         $elements = $connexion->query("Select * from agent ");
         while ($row = $elements->fetch()){?>
         
           <tr>
             <td><?php echo $row["idA"] ;?></td>
             <td><?php echo $row["nomA"] ;?></td>
             <td><?php echo $row["prenomA"] ;?></td>
             <td><?php echo $row["salaire"] ;?></td>
             <td><?php echo $row["prime"] ;?></td>
              <td><a class="btn btn-warning"
                  href="editAgent.php?idA=<?php echo $row['idA']; ?>">
                  <img src="../images/modifier.jpeg" width="30px" height="30px"></a>
              </td>
              <td><a class="btn btn-danger"
                  href="suppAgent.php?idA=<?php echo $row['idA']; ?>"
                  onclick="return confirm('êtes vous sur de vouloir vraiment supprimer');">
              <img src="../images/supprimer.png" width="30px" height="30px"></a>
             </td>
           </tr>

      <?php } ?>
    </tr>
  </tbody>
</table>
</div>
</fieldset>
</div>
<script src='../js/bootstrap.min.js'></script>
</body>
</html>