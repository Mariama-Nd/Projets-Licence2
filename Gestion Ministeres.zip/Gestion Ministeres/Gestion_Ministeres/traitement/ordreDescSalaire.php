<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
<div class="table">
 <table class="table table-success table-striped table caption-top">

  <caption><h1>Agent avec leurs salaires par ordre decroissant</h1></caption>
  <thead>
    <tr>
      <th scope="col">Prenom_Agent</th>
      <th scope="col">Nom_Agent</th>
      <th scope="col">Salaire</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
        include "../dbconnect.php";
         $elements = $connexion->query("Select prenomA,nomA,salaire from agent Order By salaire DESC");
         while ($row = $elements->fetch()){?>
         
           <tr>
             <td><?php echo $row["prenomA"] ;?></td>
             <td><?php echo $row["nomA"] ;?></td>
             <td><?php echo $row["salaire"] ;?></td>
           </tr>

      <?php } ?>
    </tr>
  </tbody>
</table>
</div>
</body>
</html>