<?php
if (isset($_POST['enregistrer'])) {
    include "../dbconnect.php";

    $idA = $_POST['idA'];
    $nomA = $_POST['nomA'];
    $prenomA = $_POST['prenomA'];
    $salaire = $_POST['salaire'];
    $prime = $_POST['prime'];

    $q = "INSERT INTO agent (idA,nomA,prenomA,salaire,prime)
        values ($idA,'$nomA','$prenomA',$salaire,$prime)";
    $connexion->exec($q);

    $location = $_SERVER['HTTP_REFERER'];
    if ($q) {
        header('Location: agent.php?');
    }
}
?>