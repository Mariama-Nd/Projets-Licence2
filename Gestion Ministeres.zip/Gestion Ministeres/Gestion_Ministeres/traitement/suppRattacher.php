<?php

include '../dbconnect.php';

$r = "DELETE FROM rattacher WHERE idR = '" . $_GET["idR"] . "'";
$connexion->query($r);
echo $r;
if ($r) {
    $location = $_SERVER['HTTP_REFERER'];
    header('Location: rattacher.php?delete=1');
}
?>