<?php
if (isset($_POST['enregistrer'])) {
    include "../dbconnect.php";

    $idR = $_POST['idR'];
    $codeS = $_POST['codeS'];
    $codeM = $_POST['codeM'];
    $dated = $_POST['dated'];
    $datef = $_POST['datef'];
    $budget = $_POST['budget'];

    $q = "INSERT INTO rattacher (idR,codeS,codeM,dated,datef,budget)
        values ($idR,$codeS,$codeM,'$dated','$datef',$budget)";
    $connexion->exec($q);

    $location = $_SERVER['HTTP_REFERER'];
    if ($q) {
        header('Location: rattacher.php?success=1');
    }
}
?>