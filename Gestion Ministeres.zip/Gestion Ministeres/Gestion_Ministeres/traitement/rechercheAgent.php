<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>agent</title>
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <link rel="stylesheet" href="../dossier/css/pages.css">
    <link rel="stylesheet" href="../dossier/css/style.css">
</head>
<body>
   <?php  include "../entete.php";?>

<div class="table">
 <table class="table table-success table-striped table caption-top">
  <thead>
    <tr>
    <th scope="col">Id Agent</th>
      <th scope="col">Nom Agent</th>
      <th scope="col">Prenom Agent</th>
      <th scope="col">Salaire</th>
      <th scope="col">Prime</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
      
        include '../dbconnect.php';

        if (isset($_POST['rechercher'])) {

            $idA = $_POST['idA'];
            $elements = $connexion->query("Select * from agent WHERE idA = '". $idA . "'");
           while ($row = $elements->fetch()){?>
         
           <tr>
           <td><?php echo $row["idA"] ;?></td>
             <td><?php echo $row["nomA"] ;?></td>
             <td><?php echo $row["prenomA"] ;?></td>
             <td><?php echo $row["salaire"] ;?></td>
             <td><?php echo $row["prime"] ;?></td>
           </tr>

      <?php } }?>
    </tr>
  </tbody>
</table>
</div>
<script src='../js/bootstrap.min.js'></script>
</body>
</html>