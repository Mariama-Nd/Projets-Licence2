<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../dossier/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
<div class="table">
 <table class="table table-success table-striped table caption-top">

  <caption><h1>Agent ayant la plus grande prime</h1></caption>
  <thead>
    <tr>
      <th scope="col">Prenom_Agent</th>
      <th scope="col">Nom_Agent</th>
      <th scope="col">Prime</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php 
        include "../dbconnect.php";
         $elements = $connexion->query("Select prenomA,nomA ,prime from agent where prime=(select Max(prime) from agent)");
         while ($row = $elements->fetch()){?>
         
           <tr>
             <td><?php echo $row["prenomA"] ;?></td>
             <td><?php echo $row["nomA"] ;?></td>
             <td><?php echo $row["prime"] ;?></td>
           </tr>

      <?php } ?>
    </tr>
  </tbody>
</table>
</div>
</body>
</html>