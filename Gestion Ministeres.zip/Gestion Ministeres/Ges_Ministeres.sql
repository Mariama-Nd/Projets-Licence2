-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : jeu. 06 juin 2024 à 17:36
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `Mariama_Ndiaye`
--

-- --------------------------------------------------------

--
-- Structure de la table `affecter`
--

CREATE TABLE `affecter` (
  `numero` int(11) NOT NULL,
  `codeS` int(11) DEFAULT NULL,
  `idA` int(11) DEFAULT NULL,
  `dateAf` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `affecter`
--

INSERT INTO `affecter` (`numero`, `codeS`, `idA`, `dateAf`) VALUES
(1, 1, 1, '2023-07-03'),
(2, 6, 4, '2024-05-03'),
(3, 2, 5, '2024-04-18'),
(4, 6, 2, '2024-05-11');

-- --------------------------------------------------------

--
-- Structure de la table `agent`
--

CREATE TABLE `agent` (
  `idA` int(11) NOT NULL,
  `nomA` varchar(50) DEFAULT NULL,
  `prenomA` varchar(50) DEFAULT NULL,
  `salaire` int(11) DEFAULT NULL,
  `prime` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `agent`
--

INSERT INTO `agent` (`idA`, `nomA`, `prenomA`, `salaire`, `prime`) VALUES
(1, 'faye', 'amina', 400000, 20000),
(2, 'Gueye', 'Omar', 280000, 50000),
(4, 'sene', 'moussa', 250000, 45000),
(5, 'Ba', 'Aissa', 350000, 35000),
(12, 'Ndiaye', 'mariam', 2000, 56),
(55, 'Gedeon', 'boss', 67675665, 577570);

-- --------------------------------------------------------

--
-- Structure de la table `ministere`
--

CREATE TABLE `ministere` (
  `codeM` int(11) NOT NULL,
  `nomM` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `ministere`
--

INSERT INTO `ministere` (`codeM`, `nomM`) VALUES
(1, 'Ministère de le santé'),
(2, 'Ministère des affaires étrangeres'),
(3, 'Ministere du sport'),
(4, 'Ministère des finances'),
(5, 'Ministère de la Femme');

-- --------------------------------------------------------

--
-- Structure de la table `rattacher`
--

CREATE TABLE `rattacher` (
  `idR` int(11) NOT NULL,
  `codeS` int(11) DEFAULT NULL,
  `codeM` int(11) DEFAULT NULL,
  `dated` date DEFAULT NULL,
  `datef` date DEFAULT NULL,
  `budget` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `rattacher`
--

INSERT INTO `rattacher` (`idR`, `codeS`, `codeM`, `dated`, `datef`, `budget`) VALUES
(1, 1, 1, '2023-10-03', '2024-05-09', 500000),
(2, 6, 2, '2024-01-06', '2024-05-26', 18000000),
(3, 2, 3, '2022-10-05', '2023-12-01', 10000000),
(5, 2, 4, '2023-11-10', '2024-06-08', 30000000);

-- --------------------------------------------------------

--
-- Structure de la table `services`
--

CREATE TABLE `services` (
  `codeS` int(11) NOT NULL,
  `nomS` varchar(50) DEFAULT NULL,
  `descript` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `services`
--

INSERT INTO `services` (`codeS`, `nomS`, `descript`) VALUES
(1, 'markting', 'gestion de tous ce qui est markting'),
(2, 'informatique', 'dhwsdxgsjdh'),
(6, 'ressources humaines', 'sdwefrzui');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `email` varchar(30) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `pass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`email`, `nom`, `pass`) VALUES
('dioufaliou@uahb.sn', 'aliou', 'b9454f0774a7b4d716ad849b4458a1b0734462ba'),
('fatou@gmail.com', 'Fatou', 'fc1200c7a7aa52109d762a9f005b149abef01479'),
('nana@gmail.com', 'nana', '8cb2237d0679ca88db6464eac60da96345513964'),
('ndiayemama868@gmail.com', 'Ndiaye', '1203b6992212536ccc813a195c1169a5f83be694');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `affecter`
--
ALTER TABLE `affecter`
  ADD PRIMARY KEY (`numero`),
  ADD KEY `codeS` (`codeS`),
  ADD KEY `idA` (`idA`);

--
-- Index pour la table `agent`
--
ALTER TABLE `agent`
  ADD PRIMARY KEY (`idA`);

--
-- Index pour la table `ministere`
--
ALTER TABLE `ministere`
  ADD PRIMARY KEY (`codeM`);

--
-- Index pour la table `rattacher`
--
ALTER TABLE `rattacher`
  ADD PRIMARY KEY (`idR`),
  ADD KEY `codeS` (`codeS`),
  ADD KEY `codeM` (`codeM`);

--
-- Index pour la table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`codeS`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`email`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `affecter`
--
ALTER TABLE `affecter`
  ADD CONSTRAINT `affecter_ibfk_1` FOREIGN KEY (`codeS`) REFERENCES `services` (`codeS`),
  ADD CONSTRAINT `affecter_ibfk_2` FOREIGN KEY (`idA`) REFERENCES `agent` (`idA`);

--
-- Contraintes pour la table `rattacher`
--
ALTER TABLE `rattacher`
  ADD CONSTRAINT `rattacher_ibfk_1` FOREIGN KEY (`codeS`) REFERENCES `services` (`codeS`),
  ADD CONSTRAINT `rattacher_ibfk_2` FOREIGN KEY (`codeM`) REFERENCES `ministere` (`codeM`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
